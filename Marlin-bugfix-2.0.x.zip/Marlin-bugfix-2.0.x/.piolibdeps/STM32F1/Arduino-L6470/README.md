# Arduino-L6470

A small library supporting ST micro L6470 stepper drivers with true 128 micro-steps resolution.

## Project Status

This library was never fully finished. It may be useful for someone to use but I assure you there are more than a few bugs in it.

Currently this is being patched up, so if you encounter any issues, please let us know.